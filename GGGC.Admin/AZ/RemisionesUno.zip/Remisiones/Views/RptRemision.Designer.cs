namespace GGGC.Admin.AZ.Remisiones.Views
{
	partial class RptRemision
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RptRemision));
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.shpFolio = new Telerik.Reporting.Shape();
            this.txtEmisorNombre = new Telerik.Reporting.TextBox();
            this.txtEmisorRFC = new Telerik.Reporting.TextBox();
            this.txtEmisorExpedido = new Telerik.Reporting.TextBox();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.txtReceptorNombre = new Telerik.Reporting.TextBox();
            this.txtReceptorCiudad = new Telerik.Reporting.TextBox();
            this.txtReceptorColonia = new Telerik.Reporting.TextBox();
            this.txtReceptorDireccion = new Telerik.Reporting.TextBox();
            this.txtReceptorRFC = new Telerik.Reporting.TextBox();
            this.txtFecha = new Telerik.Reporting.TextBox();
            this.txtCondicionPago = new Telerik.Reporting.TextBox();
            this.txtMetodoDePago = new Telerik.Reporting.TextBox();
            this.txtPedido = new Telerik.Reporting.TextBox();
            this.txtNumeroDeFolio = new Telerik.Reporting.TextBox();
            this.txtTipoCFD = new Telerik.Reporting.TextBox();
            this.txtEmplelado = new Telerik.Reporting.TextBox();
            this.txtTels = new Telerik.Reporting.TextBox();
            this.txtNumeroDeCliente = new Telerik.Reporting.TextBox();
            this.pbxLogo = new Telerik.Reporting.PictureBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.txtCuentas = new Telerik.Reporting.TextBox();
            this.textBox12 = new Telerik.Reporting.TextBox();
            this.textBox13 = new Telerik.Reporting.TextBox();
            this.textBox14 = new Telerik.Reporting.TextBox();
            this.textBox15 = new Telerik.Reporting.TextBox();
            this.textBox16 = new Telerik.Reporting.TextBox();
            this.textBox17 = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.shape10 = new Telerik.Reporting.Shape();
            this.pictureBox1 = new Telerik.Reporting.PictureBox();
            this.panel1 = new Telerik.Reporting.Panel();
            this.textBox31 = new Telerik.Reporting.TextBox();
            this.htmlPagare = new Telerik.Reporting.HtmlTextBox();
            this.textBox24 = new Telerik.Reporting.TextBox();
            this.textBox28 = new Telerik.Reporting.TextBox();
            this.txtNoCertificado = new Telerik.Reporting.TextBox();
            this.textBox30 = new Telerik.Reporting.TextBox();
            this.txtSelloDigital = new Telerik.Reporting.TextBox();
            this.txtSelloSAT = new Telerik.Reporting.TextBox();
            this.textBox37 = new Telerik.Reporting.TextBox();
            this.textBox38 = new Telerik.Reporting.TextBox();
            this.txtCadenaSAT = new Telerik.Reporting.TextBox();
            this.textBox40 = new Telerik.Reporting.TextBox();
            this.htmlTimbreFecha = new Telerik.Reporting.HtmlTextBox();
            this.textBox29 = new Telerik.Reporting.TextBox();
            this.textBox33 = new Telerik.Reporting.TextBox();
            this.textBox34 = new Telerik.Reporting.TextBox();
            this.textBox39 = new Telerik.Reporting.TextBox();
            this.textBox43 = new Telerik.Reporting.TextBox();
            this.htmlMoneda = new Telerik.Reporting.HtmlTextBox();
            this.htmlTextBox3 = new Telerik.Reporting.HtmlTextBox();
            this.htmlTextBox6 = new Telerik.Reporting.HtmlTextBox();
            this.htmlEtiquetaIVA = new Telerik.Reporting.HtmlTextBox();
            this.htmlSubTotalIVA = new Telerik.Reporting.HtmlTextBox();
            this.htmlTotal = new Telerik.Reporting.HtmlTextBox();
            this.table1 = new Telerik.Reporting.Table();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox8 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.textBox10 = new Telerik.Reporting.TextBox();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.objectDataSource1 = new Telerik.Reporting.ObjectDataSource();
            this.shape2 = new Telerik.Reporting.Shape();
            this.shape5 = new Telerik.Reporting.Shape();
            this.shape7 = new Telerik.Reporting.Shape();
            this.shape8 = new Telerik.Reporting.Shape();
            this.shape9 = new Telerik.Reporting.Shape();
            this.textBox27 = new Telerik.Reporting.TextBox();
            this.txtNota = new Telerik.Reporting.TextBox();
            this.txtTotal = new Telerik.Reporting.TextBox();
            this.txtIVA = new Telerik.Reporting.TextBox();
            this.txtSubtotal = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.shape3 = new Telerik.Reporting.Shape();
            this.txtRegimen = new Telerik.Reporting.TextBox();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.htmlTextBox1 = new Telerik.Reporting.HtmlTextBox();
            this.htmlCantidadLetras = new Telerik.Reporting.HtmlTextBox();
            this.txtCancelacion = new Telerik.Reporting.TextBox();
            this.textBox18 = new Telerik.Reporting.TextBox();
            this.pageFooterSection1 = new Telerik.Reporting.PageFooterSection();
            this.htmlTextBox4 = new Telerik.Reporting.HtmlTextBox();
            this.htmlTextBox5 = new Telerik.Reporting.HtmlTextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Inch(1.9857667684555054D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.shpFolio,
            this.txtEmisorNombre,
            this.txtEmisorRFC,
            this.txtEmisorExpedido,
            this.textBox3,
            this.txtReceptorNombre,
            this.txtReceptorCiudad,
            this.txtReceptorColonia,
            this.txtReceptorDireccion,
            this.txtReceptorRFC,
            this.txtFecha,
            this.txtCondicionPago,
            this.txtMetodoDePago,
            this.txtPedido,
            this.txtNumeroDeFolio,
            this.txtTipoCFD,
            this.txtEmplelado,
            this.txtTels,
            this.txtNumeroDeCliente,
            this.pbxLogo,
            this.textBox5,
            this.txtCuentas,
            this.textBox12,
            this.textBox13,
            this.textBox14,
            this.textBox15,
            this.textBox16,
            this.textBox17});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // shpFolio
            // 
            this.shpFolio.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.636874198913574D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.shpFolio.Name = "shpFolio";
            this.shpFolio.ShapeType = new Telerik.Reporting.Drawing.Shapes.PolygonShape(4, 45D, 5);
            this.shpFolio.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.7735414505004883D), Telerik.Reporting.Drawing.Unit.Cm(0.89999997615814209D));
            this.shpFolio.Stretch = true;
            this.shpFolio.Style.Color = System.Drawing.Color.Black;
            this.shpFolio.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(1D);
            // 
            // txtEmisorNombre
            // 
            this.txtEmisorNombre.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.1960415840148926D), Telerik.Reporting.Drawing.Unit.Cm(-0.026458332315087318D));
            this.txtEmisorNombre.Name = "txtEmisorNombre";
            this.txtEmisorNombre.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13.300000190734863D), Telerik.Reporting.Drawing.Unit.Cm(0.89999997615814209D));
            this.txtEmisorNombre.Style.Color = System.Drawing.Color.White;
            this.txtEmisorNombre.Style.Font.Bold = true;
            this.txtEmisorNombre.Style.Font.Name = "Times New Roman";
            this.txtEmisorNombre.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(14D);
            this.txtEmisorNombre.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.txtEmisorNombre.Style.Visible = true;
            this.txtEmisorNombre.Value = "textBox2";
            // 
            // txtEmisorRFC
            // 
            this.txtEmisorRFC.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.0372915267944336D), Telerik.Reporting.Drawing.Unit.Cm(0.5027083158493042D));
            this.txtEmisorRFC.Name = "txtEmisorRFC";
            this.txtEmisorRFC.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(14.983333587646484D), Telerik.Reporting.Drawing.Unit.Cm(0.49980071187019348D));
            this.txtEmisorRFC.Style.Font.Bold = true;
            this.txtEmisorRFC.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtEmisorRFC.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.txtEmisorRFC.Value = "";
            // 
            // txtEmisorExpedido
            // 
            this.txtEmisorExpedido.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.509374618530273D), Telerik.Reporting.Drawing.Unit.Cm(2.3283333778381348D));
            this.txtEmisorExpedido.Name = "txtEmisorExpedido";
            this.txtEmisorExpedido.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5666704177856445D), Telerik.Reporting.Drawing.Unit.Cm(1.2998001575469971D));
            this.txtEmisorExpedido.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.txtEmisorExpedido.Value = "";
            // 
            // textBox3
            // 
            this.textBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.509374618530273D), Telerik.Reporting.Drawing.Unit.Cm(1.984375D));
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.4000000953674316D), Telerik.Reporting.Drawing.Unit.Cm(0.28813403844833374D));
            this.textBox3.Style.Font.Bold = true;
            this.textBox3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox3.Value = "EXPEDIDO EN :";
            // 
            // txtReceptorNombre
            // 
            this.txtReceptorNombre.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(2.3547916412353516D));
            this.txtReceptorNombre.Name = "txtReceptorNombre";
            this.txtReceptorNombre.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.100000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtReceptorNombre.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtReceptorNombre.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtReceptorNombre.Style.Font.Bold = true;
            this.txtReceptorNombre.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtReceptorNombre.Value = "";
            // 
            // txtReceptorCiudad
            // 
            this.txtReceptorCiudad.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(3.5718748569488525D));
            this.txtReceptorCiudad.Name = "txtReceptorCiudad";
            this.txtReceptorCiudad.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.100000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtReceptorCiudad.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtReceptorCiudad.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtReceptorCiudad.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtReceptorCiudad.Value = "";
            // 
            // txtReceptorColonia
            // 
            this.txtReceptorColonia.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(3.1485416889190674D));
            this.txtReceptorColonia.Name = "txtReceptorColonia";
            this.txtReceptorColonia.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.100000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtReceptorColonia.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtReceptorColonia.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtReceptorColonia.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtReceptorColonia.Value = "";
            // 
            // txtReceptorDireccion
            // 
            this.txtReceptorDireccion.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(2.75166654586792D));
            this.txtReceptorDireccion.Name = "txtReceptorDireccion";
            this.txtReceptorDireccion.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.100000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtReceptorDireccion.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtReceptorDireccion.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtReceptorDireccion.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtReceptorDireccion.Value = "";
            // 
            // txtReceptorRFC
            // 
            this.txtReceptorRFC.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(3.9952082633972168D));
            this.txtReceptorRFC.Name = "txtReceptorRFC";
            this.txtReceptorRFC.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.100000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtReceptorRFC.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtReceptorRFC.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtReceptorRFC.Style.Font.Bold = true;
            this.txtReceptorRFC.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtReceptorRFC.Value = "";
            // 
            // txtFecha
            // 
            this.txtFecha.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.82208251953125D), Telerik.Reporting.Drawing.Unit.Cm(1.6404166221618652D));
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.082916259765625D), Telerik.Reporting.Drawing.Unit.Cm(0.50583332777023315D));
            this.txtFecha.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtFecha.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtFecha.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
            this.txtFecha.Value = "";
            // 
            // txtCondicionPago
            // 
            this.txtCondicionPago.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.626041412353516D), Telerik.Reporting.Drawing.Unit.Cm(4.1539583206176758D));
            this.txtCondicionPago.Name = "txtCondicionPago";
            this.txtCondicionPago.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.1937499046325684D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtCondicionPago.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtCondicionPago.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtCondicionPago.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtCondicionPago.Style.Visible = false;
            this.txtCondicionPago.Value = "";
            // 
            // txtMetodoDePago
            // 
            this.txtMetodoDePago.CanGrow = true;
            this.txtMetodoDePago.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.626041412353516D), Telerik.Reporting.Drawing.Unit.Cm(4.2333331108093262D));
            this.txtMetodoDePago.Multiline = false;
            this.txtMetodoDePago.Name = "txtMetodoDePago";
            this.txtMetodoDePago.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9000000953674316D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtMetodoDePago.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtMetodoDePago.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtMetodoDePago.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtMetodoDePago.Style.Visible = false;
            this.txtMetodoDePago.Value = "TRANSFERENCIAS ELECTRONICAS DE FONDOS";
            // 
            // txtPedido
            // 
            this.txtPedido.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.626041412353516D), Telerik.Reporting.Drawing.Unit.Cm(3.7835416793823242D));
            this.txtPedido.Name = "txtPedido";
            this.txtPedido.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3650000095367432D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtPedido.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtPedido.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtPedido.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtPedido.Style.Visible = false;
            this.txtPedido.Value = "";
            // 
            // txtNumeroDeFolio
            // 
            this.txtNumeroDeFolio.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.779998779296875D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.txtNumeroDeFolio.Name = "txtNumeroDeFolio";
            this.txtNumeroDeFolio.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4900000095367432D), Telerik.Reporting.Drawing.Unit.Cm(0.800000011920929D));
            this.txtNumeroDeFolio.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.txtNumeroDeFolio.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.txtNumeroDeFolio.Style.Color = System.Drawing.Color.Black;
            this.txtNumeroDeFolio.Style.Font.Bold = true;
            this.txtNumeroDeFolio.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
            this.txtNumeroDeFolio.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.txtNumeroDeFolio.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.txtNumeroDeFolio.Value = "";
            // 
            // txtTipoCFD
            // 
            this.txtTipoCFD.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.689791679382324D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.txtTipoCFD.Name = "txtTipoCFD";
            this.txtTipoCFD.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5158336162567139D), Telerik.Reporting.Drawing.Unit.Cm(0.793958306312561D));
            this.txtTipoCFD.Style.Font.Bold = true;
            this.txtTipoCFD.Style.Font.Name = "Tahoma";
            this.txtTipoCFD.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.txtTipoCFD.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.txtTipoCFD.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.txtTipoCFD.Value = "REMISI�N";
            // 
            // txtEmplelado
            // 
            this.txtEmplelado.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.912290573120117D), Telerik.Reporting.Drawing.Unit.Cm(4.04812479019165D));
            this.txtEmplelado.Name = "txtEmplelado";
            this.txtEmplelado.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.4577085971832275D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtEmplelado.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtEmplelado.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtEmplelado.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtEmplelado.Style.Visible = false;
            this.txtEmplelado.Value = "";
            // 
            // txtTels
            // 
            this.txtTels.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(3.96875D));
            this.txtTels.Multiline = false;
            this.txtTels.Name = "txtTels";
            this.txtTels.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.100000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.txtTels.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtTels.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtTels.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtTels.Style.Visible = false;
            this.txtTels.Value = "";
            // 
            // txtNumeroDeCliente
            // 
            this.txtNumeroDeCliente.CanGrow = false;
            this.txtNumeroDeCliente.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.18520833551883698D), Telerik.Reporting.Drawing.Unit.Cm(2.0108332633972168D));
            this.txtNumeroDeCliente.Multiline = false;
            this.txtNumeroDeCliente.Name = "txtNumeroDeCliente";
            this.txtNumeroDeCliente.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6535423994064331D), Telerik.Reporting.Drawing.Unit.Cm(0.2941666841506958D));
            this.txtNumeroDeCliente.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtNumeroDeCliente.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtNumeroDeCliente.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.txtNumeroDeCliente.Value = "";
            // 
            // pbxLogo
            // 
            this.pbxLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(-0.026458332315087318D));
            this.pbxLogo.MimeType = "image/jpeg";
            this.pbxLogo.Name = "pbxLogo";
            this.pbxLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.8400001525878906D), Telerik.Reporting.Drawing.Unit.Cm(1.3300000429153442D));
            this.pbxLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pbxLogo.Value = ((object)(resources.GetObject("pbxLogo.Value")));
            // 
            // textBox5
            // 
            this.textBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.1912498474121094D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.0752077102661133D), Telerik.Reporting.Drawing.Unit.Cm(0.60854166746139526D));
            this.textBox5.Style.Color = System.Drawing.Color.Navy;
            this.textBox5.Style.Font.Bold = true;
            this.textBox5.Style.Font.Name = "Tahoma";
            this.textBox5.Value = "LLANTAS Y RINES DEL GUADIANA S.A. DE C.V.";
            // 
            // txtCuentas
            // 
            this.txtCuentas.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.626041412353516D), Telerik.Reporting.Drawing.Unit.Cm(4.259791374206543D));
            this.txtCuentas.Name = "txtCuentas";
            this.txtCuentas.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5900001525878906D), Telerik.Reporting.Drawing.Unit.Cm(0.64999997615814209D));
            this.txtCuentas.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.txtCuentas.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtCuentas.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtCuentas.Style.Visible = false;
            this.txtCuentas.Value = "";
            // 
            // textBox12
            // 
            this.textBox12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.901457786560059D), Telerik.Reporting.Drawing.Unit.Cm(1.1112499237060547D));
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1600000858306885D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox12.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox12.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox12.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox12.Value = "FECHA:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.72166633605957D), Telerik.Reporting.Drawing.Unit.Cm(4.0745830535888672D));
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.0612497329711914D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox13.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox13.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox13.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox13.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox13.Style.Visible = false;
            this.textBox13.Value = "NO. EMP:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.482915878295898D), Telerik.Reporting.Drawing.Unit.Cm(3.8893749713897705D));
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.190000057220459D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox14.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox14.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox14.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox14.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox14.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox14.Style.Visible = false;
            this.textBox14.Value = "NO.  PEDIDO:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.482915878295898D), Telerik.Reporting.Drawing.Unit.Cm(4.1539583206176758D));
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1879167556762695D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox15.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox15.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox15.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox15.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox15.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox15.Style.Visible = false;
            this.textBox15.Value = "CONDICI�N PAGO:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.482915878295898D), Telerik.Reporting.Drawing.Unit.Cm(4.127500057220459D));
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1614582538604736D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox16.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox16.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox16.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox16.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox16.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox16.Style.Visible = false;
            this.textBox16.Value = "M�TODO DE PAGO:";
            // 
            // textBox17
            // 
            this.textBox17.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.482915878295898D), Telerik.Reporting.Drawing.Unit.Cm(4.2333331108093262D));
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1600000858306885D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox17.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox17.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox17.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox17.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox17.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox17.Style.Visible = false;
            this.textBox17.Value = "NO. CUENTA:";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Inch(8.0000009536743164D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.shape10,
            this.pictureBox1,
            this.panel1,
            this.textBox28,
            this.txtNoCertificado,
            this.textBox30,
            this.txtSelloDigital,
            this.txtSelloSAT,
            this.textBox37,
            this.textBox38,
            this.txtCadenaSAT,
            this.textBox40,
            this.htmlTimbreFecha,
            this.textBox29,
            this.textBox33,
            this.textBox34,
            this.textBox39,
            this.textBox43,
            this.htmlMoneda,
            this.htmlTextBox3,
            this.htmlTextBox6,
            this.htmlEtiquetaIVA,
            this.htmlSubTotalIVA,
            this.htmlTotal,
            this.table1,
            this.shape2,
            this.shape5,
            this.shape7,
            this.shape8,
            this.shape9,
            this.textBox27,
            this.txtNota,
            this.txtTotal,
            this.txtIVA,
            this.txtSubtotal,
            this.textBox2,
            this.shape3,
            this.txtRegimen,
            this.textBox11,
            this.htmlTextBox1,
            this.htmlCantidadLetras,
            this.txtCancelacion,
            this.textBox18});
            this.detail.Name = "detail";
            // 
            // shape10
            // 
            this.shape10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.2100152969360352D));
            this.shape10.Name = "shape10";
            this.shape10.ShapeType = new Telerik.Reporting.Drawing.Shapes.PolygonShape(4, 45D, 3);
            this.shape10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(20.280000686645508D), Telerik.Reporting.Drawing.Unit.Cm(1.3500000238418579D));
            this.shape10.Stretch = true;
            this.shape10.Style.Color = System.Drawing.Color.Black;
            this.shape10.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(1D);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.017999649047852D), Telerik.Reporting.Drawing.Unit.Cm(15.784152030944824D));
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.pictureBox1.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.Stretch;
            // 
            // panel1
            // 
            this.panel1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox31,
            this.htmlPagare,
            this.textBox24});
            this.panel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(11.041056632995606D));
            this.panel1.Name = "panel1";
            this.panel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(20.350000381469727D), Telerik.Reporting.Drawing.Unit.Cm(3.3610498905181885D));
            this.panel1.Style.BorderColor.Default = System.Drawing.Color.Black;
            this.panel1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.panel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.panel1.Style.Color = System.Drawing.Color.Black;
            // 
            // textBox31
            // 
            this.textBox31.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.12645833194255829D), Telerik.Reporting.Drawing.Unit.Cm(0.1483333557844162D));
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8.2535419464111328D), Telerik.Reporting.Drawing.Unit.Cm(1.4762504100799561D));
            this.textBox31.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox31.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox31.Value = "Recib� de conformidad la\r\nmercancia arriba citada ";
            // 
            // htmlPagare
            // 
            this.htmlPagare.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.5324983596801758D), Telerik.Reporting.Drawing.Unit.Cm(0.20875744521617889D));
            this.htmlPagare.Name = "htmlPagare";
            this.htmlPagare.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.567501068115234D), Telerik.Reporting.Drawing.Unit.Cm(2.2466666698455811D));
            this.htmlPagare.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.htmlPagare.Style.Visible = false;
            this.htmlPagare.Value = resources.GetString("htmlPagare.Value");
            // 
            // textBox24
            // 
            this.textBox24.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.20583125948905945D), Telerik.Reporting.Drawing.Unit.Cm(2.7993834018707275D));
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8.2270832061767578D), Telerik.Reporting.Drawing.Unit.Cm(0.34999999403953552D));
            this.textBox24.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox24.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox24.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox24.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox24.Value = "Nombre y Firma";
            // 
            // textBox28
            // 
            this.textBox28.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.344196319580078D), Telerik.Reporting.Drawing.Unit.Cm(14.507098197937012D));
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9999995231628418D), Telerik.Reporting.Drawing.Unit.Cm(0.50000017881393433D));
            this.textBox28.Style.BackgroundColor = System.Drawing.Color.Silver;
            this.textBox28.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox28.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox28.Style.Font.Bold = true;
            this.textBox28.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox28.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox28.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox28.Style.Visible = false;
            this.textBox28.Value = "Numero de Certificado";
            // 
            // txtNoCertificado
            // 
            this.txtNoCertificado.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.344196319580078D), Telerik.Reporting.Drawing.Unit.Cm(15.009806632995606D));
            this.txtNoCertificado.Name = "txtNoCertificado";
            this.txtNoCertificado.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.txtNoCertificado.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.txtNoCertificado.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtNoCertificado.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtNoCertificado.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.txtNoCertificado.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.txtNoCertificado.Style.Visible = false;
            this.txtNoCertificado.Value = "";
            // 
            // textBox30
            // 
            this.textBox30.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(14.507098197937012D));
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.352714538574219D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox30.Style.BackgroundColor = System.Drawing.Color.Silver;
            this.textBox30.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox30.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox30.Style.Font.Bold = true;
            this.textBox30.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox30.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox30.Style.Visible = false;
            this.textBox30.Value = "Sello digital (firma):";
            // 
            // txtSelloDigital
            // 
            this.txtSelloDigital.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(15.009806632995606D));
            this.txtSelloDigital.Name = "txtSelloDigital";
            this.txtSelloDigital.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.352716445922852D), Telerik.Reporting.Drawing.Unit.Cm(0.99980008602142334D));
            this.txtSelloDigital.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.txtSelloDigital.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtSelloDigital.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtSelloDigital.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.txtSelloDigital.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.txtSelloDigital.Style.Visible = false;
            this.txtSelloDigital.Value = "textBox33\r\ntextBox33";
            // 
            // txtSelloSAT
            // 
            this.txtSelloSAT.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(16.544389724731445D));
            this.txtSelloSAT.Name = "txtSelloSAT";
            this.txtSelloSAT.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.352716445922852D), Telerik.Reporting.Drawing.Unit.Cm(0.99980008602142334D));
            this.txtSelloSAT.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.txtSelloSAT.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtSelloSAT.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtSelloSAT.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.txtSelloSAT.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.txtSelloSAT.Style.Visible = false;
            this.txtSelloSAT.Value = "textBox33\r\ntextBox33";
            // 
            // textBox37
            // 
            this.textBox37.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(16.041681289672852D));
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.352714538574219D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox37.Style.BackgroundColor = System.Drawing.Color.Silver;
            this.textBox37.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox37.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox37.Style.Font.Bold = true;
            this.textBox37.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox37.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox37.Style.Visible = false;
            this.textBox37.Value = "Sello digital SAT:";
            // 
            // textBox38
            // 
            this.textBox38.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(17.523347854614258D));
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.352714538574219D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox38.Style.BackgroundColor = System.Drawing.Color.Silver;
            this.textBox38.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox38.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox38.Style.Font.Bold = true;
            this.textBox38.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox38.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox38.Style.Visible = false;
            this.textBox38.Value = "Cadena Original del complemento de certificaci�n digital del SAT:";
            // 
            // txtCadenaSAT
            // 
            this.txtCadenaSAT.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(18.026056289672852D));
            this.txtCadenaSAT.Name = "txtCadenaSAT";
            this.txtCadenaSAT.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.352716445922852D), Telerik.Reporting.Drawing.Unit.Cm(1.2643834352493286D));
            this.txtCadenaSAT.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.txtCadenaSAT.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtCadenaSAT.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtCadenaSAT.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.txtCadenaSAT.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.txtCadenaSAT.Value = "Soy una cadena digital XAXAXAXAXAXA";
            // 
            // textBox40
            // 
            this.textBox40.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(19.428348541259766D));
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox40.Style.Color = System.Drawing.Color.Gray;
            this.textBox40.Style.Font.Bold = true;
            this.textBox40.Style.Visible = false;
            this.textBox40.Value = "DATOS PAC";
            // 
            // htmlTimbreFecha
            // 
            this.htmlTimbreFecha.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.9298210144042969D), Telerik.Reporting.Drawing.Unit.Cm(19.428348541259766D));
            this.htmlTimbreFecha.Name = "htmlTimbreFecha";
            this.htmlTimbreFecha.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.714579582214356D), Telerik.Reporting.Drawing.Unit.Cm(0.47466909885406494D));
            this.htmlTimbreFecha.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlTimbreFecha.Style.Visible = false;
            this.htmlTimbreFecha.Value = resources.GetString("htmlTimbreFecha.Value");
            // 
            // textBox29
            // 
            this.textBox29.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.098779499530792236D), Telerik.Reporting.Drawing.Unit.Cm(0.007932332344353199D));
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5560410022735596D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox29.Style.BorderColor.Default = System.Drawing.Color.LightGray;
            this.textBox29.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox29.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox29.Style.Color = System.Drawing.Color.Black;
            this.textBox29.Style.Font.Bold = true;
            this.textBox29.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox29.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox29.Value = "C�digo";
            // 
            // textBox33
            // 
            this.textBox33.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.4908628463745117D), Telerik.Reporting.Drawing.Unit.Cm(0.007932332344353199D));
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox33.Style.BorderColor.Default = System.Drawing.Color.LightGray;
            this.textBox33.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox33.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox33.Style.Font.Bold = true;
            this.textBox33.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox33.Value = "Descripci�n";
            // 
            // textBox34
            // 
            this.textBox34.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.0356543064117432D), Telerik.Reporting.Drawing.Unit.Cm(0.007932332344353199D));
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.4997996091842651D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox34.Style.BorderColor.Default = System.Drawing.Color.LightGray;
            this.textBox34.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox34.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox34.Style.Font.Bold = true;
            this.textBox34.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox34.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Justify;
            this.textBox34.Value = "Cantidad";
            // 
            // textBox39
            // 
            this.textBox39.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.418153762817383D), Telerik.Reporting.Drawing.Unit.Cm(0.007932332344353199D));
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5252163410186768D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox39.Style.BorderColor.Default = System.Drawing.Color.LightGray;
            this.textBox39.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox39.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox39.Style.Font.Bold = true;
            this.textBox39.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox39.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox39.Value = "Precio Unitario";
            // 
            // textBox43
            // 
            this.textBox43.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.249195098876953D), Telerik.Reporting.Drawing.Unit.Cm(0.007932332344353199D));
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7887483835220337D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox43.Style.BorderColor.Default = System.Drawing.Color.LightGray;
            this.textBox43.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox43.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox43.Style.Font.Bold = true;
            this.textBox43.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox43.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox43.Value = "Importe";
            // 
            // htmlMoneda
            // 
            this.htmlMoneda.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.3741817474365234D));
            this.htmlMoneda.Name = "htmlMoneda";
            this.htmlMoneda.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13.782084465026856D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.htmlMoneda.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlMoneda.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlMoneda.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlMoneda.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlMoneda.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlMoneda.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlMoneda.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlMoneda.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.htmlMoneda.Style.Visible = false;
            this.htmlMoneda.Value = "htmlTextBox2";
            // 
            // htmlTextBox3
            // 
            this.htmlTextBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.777737617492676D), Telerik.Reporting.Drawing.Unit.Cm(8.9508485794067383D));
            this.htmlTextBox3.Name = "htmlTextBox3";
            this.htmlTextBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9999997615814209D), Telerik.Reporting.Drawing.Unit.Cm(0.59999889135360718D));
            this.htmlTextBox3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox3.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox3.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox3.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox3.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox3.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox3.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlTextBox3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.htmlTextBox3.Style.Visible = false;
            this.htmlTextBox3.Value = "Total";
            // 
            // htmlTextBox6
            // 
            this.htmlTextBox6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.788570404052734D), Telerik.Reporting.Drawing.Unit.Cm(9.0302238464355469D));
            this.htmlTextBox6.Name = "htmlTextBox6";
            this.htmlTextBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1508464813232422D), Telerik.Reporting.Drawing.Unit.Cm(0.59999889135360718D));
            this.htmlTextBox6.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox6.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox6.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox6.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox6.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox6.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox6.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox6.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox6.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlTextBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.htmlTextBox6.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.htmlTextBox6.Style.Visible = false;
            this.htmlTextBox6.Value = "Total";
            // 
            // htmlEtiquetaIVA
            // 
            this.htmlEtiquetaIVA.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.788570404052734D), Telerik.Reporting.Drawing.Unit.Cm(8.3423070907592773D));
            this.htmlEtiquetaIVA.Name = "htmlEtiquetaIVA";
            this.htmlEtiquetaIVA.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1508464813232422D), Telerik.Reporting.Drawing.Unit.Cm(0.79000020027160645D));
            this.htmlEtiquetaIVA.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlEtiquetaIVA.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlEtiquetaIVA.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlEtiquetaIVA.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlEtiquetaIVA.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlEtiquetaIVA.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlEtiquetaIVA.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlEtiquetaIVA.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlEtiquetaIVA.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.htmlEtiquetaIVA.Style.Visible = true;
            this.htmlEtiquetaIVA.Value = "Subtotal<br />";
            // 
            // htmlSubTotalIVA
            // 
            this.htmlSubTotalIVA.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.12711238861084D), Telerik.Reporting.Drawing.Unit.Cm(9.3741817474365234D));
            this.htmlSubTotalIVA.Name = "htmlSubTotalIVA";
            this.htmlSubTotalIVA.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.419581413269043D), Telerik.Reporting.Drawing.Unit.Cm(0.79000002145767212D));
            this.htmlSubTotalIVA.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlSubTotalIVA.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlSubTotalIVA.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlSubTotalIVA.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlSubTotalIVA.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlSubTotalIVA.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlSubTotalIVA.Style.BorderWidth.Right = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlSubTotalIVA.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlSubTotalIVA.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlSubTotalIVA.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.htmlSubTotalIVA.Style.Visible = false;
            this.htmlSubTotalIVA.Value = "Subtotal<br />IVA";
            // 
            // htmlTotal
            // 
            this.htmlTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.582321166992188D), Telerik.Reporting.Drawing.Unit.Cm(9.6652240753173828D));
            this.htmlTotal.Name = "htmlTotal";
            this.htmlTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4037623405456543D), Telerik.Reporting.Drawing.Unit.Cm(0.59999889135360718D));
            this.htmlTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTotal.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTotal.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTotal.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTotal.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTotal.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTotal.Style.BorderWidth.Right = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTotal.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.htmlTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.htmlTotal.Style.Visible = false;
            this.htmlTotal.Value = "Total";
            // 
            // table1
            // 
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.5999999046325684D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.6000000238418579D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(9.0000019073486328D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.9000002145767212D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.2999989986419678D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.4195821285247803D)));
            this.table1.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table1.Body.SetCellContent(0, 0, this.textBox6);
            this.table1.Body.SetCellContent(0, 2, this.textBox7);
            this.table1.Body.SetCellContent(0, 3, this.textBox8);
            this.table1.Body.SetCellContent(0, 4, this.textBox9);
            this.table1.Body.SetCellContent(0, 5, this.textBox10);
            this.table1.Body.SetCellContent(0, 1, this.textBox4);
            tableGroup2.Name = "Group22";
            this.table1.ColumnGroups.Add(tableGroup1);
            this.table1.ColumnGroups.Add(tableGroup2);
            this.table1.ColumnGroups.Add(tableGroup3);
            this.table1.ColumnGroups.Add(tableGroup4);
            this.table1.ColumnGroups.Add(tableGroup5);
            this.table1.ColumnGroups.Add(tableGroup6);
            this.table1.DataSource = this.objectDataSource1;
            this.table1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox6,
            this.textBox4,
            this.textBox7,
            this.textBox8,
            this.textBox9,
            this.textBox10});
            this.table1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.20461282134056091D), Telerik.Reporting.Drawing.Unit.Cm(0.54415279626846313D));
            this.table1.Name = "table1";
            tableGroup8.Name = "Group1";
            tableGroup7.ChildGroups.Add(tableGroup8);
            tableGroup7.Groupings.Add(new Telerik.Reporting.Grouping(""));
            tableGroup7.Name = "Detail";
            this.table1.RowGroups.Add(tableGroup7);
            this.table1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(19.819581985473633D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.table1.Style.BorderColor.Default = System.Drawing.Color.White;
            this.table1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.table1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.table1.Style.Visible = true;
            this.table1.StyleName = "";
            // 
            // textBox6
            // 
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6000001430511475D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.textBox6.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox6.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox6.StyleName = "";
            this.textBox6.Value = "= Fields.Field3";
            // 
            // textBox7
            // 
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.textBox7.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox7.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox7.StyleName = "";
            this.textBox7.Value = "= Fields.Field4";
            // 
            // textBox8
            // 
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.8999999761581421D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.textBox8.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox8.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox8.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox8.StyleName = "";
            this.textBox8.Value = "= Fields.Field8";
            // 
            // textBox9
            // 
            this.textBox9.Format = "{0:N2}";
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2999999523162842D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.textBox9.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox9.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox9.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox9.StyleName = "";
            this.textBox9.Value = "= Fields.Field6";
            // 
            // textBox10
            // 
            this.textBox10.Format = "{0:N2}";
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4195823669433594D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox10.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox10.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox10.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox10.Style.BorderWidth.Right = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox10.StyleName = "";
            this.textBox10.Value = "= Fields.Field7";
            // 
            // textBox4
            // 
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6000001430511475D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.textBox4.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox4.StyleName = "";
            this.textBox4.Value = "= Fields.Field5";
            // 
            // objectDataSource1
            // 
            this.objectDataSource1.CalculatedFields.AddRange(new Telerik.Reporting.CalculatedField[] {
            new Telerik.Reporting.CalculatedField("Field1", typeof(string), "Fields.RemisionID"),
            new Telerik.Reporting.CalculatedField("Field2", typeof(string), "Fields.RemisionDetailID"),
            new Telerik.Reporting.CalculatedField("Field3", typeof(string), "Fields.CodeID"),
            new Telerik.Reporting.CalculatedField("Field4", typeof(string), "Fields.ProductDescription"),
            new Telerik.Reporting.CalculatedField("Field5", typeof(string), "Fields.Qty"),
            new Telerik.Reporting.CalculatedField("Field6", typeof(string), "Fields.UnitPrice"),
            new Telerik.Reporting.CalculatedField("Field7", typeof(string), "Fields.LineTotal"),
            new Telerik.Reporting.CalculatedField("Field8", typeof(string), "Fields.UnitID")});
            this.objectDataSource1.Name = "objectDataSource1";
            // 
            // shape2
            // 
            this.shape2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.7446126937866211D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.shape2.Name = "shape2";
            this.shape2.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.NS);
            this.shape2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.20999999344348908D), Telerik.Reporting.Drawing.Unit.Cm(8D));
            this.shape2.Style.Color = System.Drawing.Color.Black;
            // 
            // shape5
            // 
            this.shape5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.1998209953308105D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.shape5.Name = "shape5";
            this.shape5.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.NS);
            this.shape5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.20999999344348908D), Telerik.Reporting.Drawing.Unit.Cm(8D));
            this.shape5.Style.Color = System.Drawing.Color.Black;
            // 
            // shape7
            // 
            this.shape7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.412737846374512D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.shape7.Name = "shape7";
            this.shape7.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.NS);
            this.shape7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.20999999344348908D), Telerik.Reporting.Drawing.Unit.Cm(8D));
            this.shape7.Style.Color = System.Drawing.Color.Black;
            // 
            // shape8
            // 
            this.shape8.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.011070251464844D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.shape8.Name = "shape8";
            this.shape8.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.NS);
            this.shape8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.12999999523162842D), Telerik.Reporting.Drawing.Unit.Cm(8D));
            this.shape8.Style.Color = System.Drawing.Color.Black;
            this.shape8.Style.Visible = true;
            // 
            // shape9
            // 
            this.shape9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.37834897637367249D));
            this.shape9.Name = "shape9";
            this.shape9.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(20.319999694824219D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.shape9.Style.Color = System.Drawing.Color.Black;
            // 
            // textBox27
            // 
            this.textBox27.CanGrow = false;
            this.textBox27.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0458628311753273D), Telerik.Reporting.Drawing.Unit.Cm(10.776473999023438D));
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(14.832291603088379D), Telerik.Reporting.Drawing.Unit.Cm(0.3470839262008667D));
            this.textBox27.Style.Color = System.Drawing.Color.Black;
            this.textBox27.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox27.Style.Visible = false;
            this.textBox27.Value = "Todo Cheque Devuelto causar� un m�nimo de 20% de cargo de acuerdo con el art. 193" +
    " de la Ley General de T�tulos y Operaciones de Cr�dito.  R�g Fiscal:";
            // 
            // txtNota
            // 
            this.txtNota.CanGrow = false;
            this.txtNota.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.6387653350830078D));
            this.txtNota.Multiline = true;
            this.txtNota.Name = "txtNota";
            this.txtNota.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(20.319999694824219D), Telerik.Reporting.Drawing.Unit.Cm(0.796875D));
            this.txtNota.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.txtNota.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.txtNota.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.txtNota.Style.Font.Italic = true;
            this.txtNota.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtNota.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.txtNota.Value = "";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.011070251464844D), Telerik.Reporting.Drawing.Unit.Cm(9.1095991134643555D));
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.47999998927116394D));
            this.txtTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.txtTotal.Style.Visible = false;
            this.txtTotal.Value = "";
            // 
            // txtIVA
            // 
            this.txtIVA.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.011070251464844D), Telerik.Reporting.Drawing.Unit.Cm(8.6598072052001953D));
            this.txtIVA.Name = "txtIVA";
            this.txtIVA.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.47999998927116394D));
            this.txtIVA.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.txtIVA.Style.Visible = false;
            this.txtIVA.Value = "";
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.011070251464844D), Telerik.Reporting.Drawing.Unit.Cm(8.1835575103759766D));
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.47999998927116394D));
            this.txtSubtotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.txtSubtotal.Style.Visible = true;
            this.txtSubtotal.Value = "";
            // 
            // textBox2
            // 
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.931071281433106D), Telerik.Reporting.Drawing.Unit.Cm(0.007932332344353199D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5027093887329102D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox2.Style.BorderColor.Default = System.Drawing.Color.LightGray;
            this.textBox2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox2.Style.Font.Bold = true;
            this.textBox2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox2.Value = "Unidad M";
            // 
            // shape3
            // 
            this.shape3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.851696014404297D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.shape3.Name = "shape3";
            this.shape3.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.NS);
            this.shape3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.20999999344348908D), Telerik.Reporting.Drawing.Unit.Cm(8D));
            this.shape3.Style.Color = System.Drawing.Color.Black;
            // 
            // txtRegimen
            // 
            this.txtRegimen.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.67732048034668D), Telerik.Reporting.Drawing.Unit.Cm(10.776473999023438D));
            this.txtRegimen.Name = "txtRegimen";
            this.txtRegimen.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.704167366027832D), Telerik.Reporting.Drawing.Unit.Cm(0.3470839262008667D));
            this.txtRegimen.Style.Color = System.Drawing.Color.Black;
            this.txtRegimen.Style.Font.Bold = true;
            this.txtRegimen.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.txtRegimen.Style.Visible = false;
            this.txtRegimen.Value = "R�GIMEN GENERAL DE LEY DE PERSONAS MORALES";
            // 
            // textBox11
            // 
            this.textBox11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.019404498860239983D), Telerik.Reporting.Drawing.Unit.Cm(19.825223922729492D));
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0902082920074463D), Telerik.Reporting.Drawing.Unit.Cm(0.34395831823349D));
            this.textBox11.Style.Font.Bold = true;
            this.textBox11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox11.Style.Visible = false;
            this.textBox11.Value = "Versi�n: 3.2";
            // 
            // htmlTextBox1
            // 
            this.htmlTextBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.777737617492676D), Telerik.Reporting.Drawing.Unit.Cm(8.3687658309936523D));
            this.htmlTextBox1.Name = "htmlTextBox1";
            this.htmlTextBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9999997615814209D), Telerik.Reporting.Drawing.Unit.Cm(0.79000020027160645D));
            this.htmlTextBox1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox1.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox1.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox1.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlTextBox1.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox1.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlTextBox1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlTextBox1.Style.Visible = false;
            this.htmlTextBox1.Value = "Subtotal<br />";
            // 
            // htmlCantidadLetras
            // 
            this.htmlCantidadLetras.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.2100152969360352D));
            this.htmlCantidadLetras.Name = "htmlCantidadLetras";
            this.htmlCantidadLetras.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13.779999732971191D), Telerik.Reporting.Drawing.Unit.Cm(1.1339583396911621D));
            this.htmlCantidadLetras.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlCantidadLetras.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlCantidadLetras.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlCantidadLetras.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlCantidadLetras.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.htmlCantidadLetras.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlCantidadLetras.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlCantidadLetras.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlCantidadLetras.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.htmlCantidadLetras.Style.Font.Bold = false;
            this.htmlCantidadLetras.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlCantidadLetras.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.htmlCantidadLetras.Value = "<p><strong>Importe con letra: <br /></strong>{0}</p><p></p>";
            // 
            // txtCancelacion
            // 
            this.txtCancelacion.CanGrow = false;
            this.txtCancelacion.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.019404498860239983D), Telerik.Reporting.Drawing.Unit.Cm(10.45897388458252D));
            this.txtCancelacion.Name = "txtCancelacion";
            this.txtCancelacion.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(14.832291603088379D), Telerik.Reporting.Drawing.Unit.Cm(0.3470839262008667D));
            this.txtCancelacion.Style.Color = System.Drawing.Color.Black;
            this.txtCancelacion.Style.Font.Bold = false;
            this.txtCancelacion.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.txtCancelacion.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.txtCancelacion.Style.Visible = false;
            this.txtCancelacion.Value = "";
            // 
            // textBox18
            // 
            this.textBox18.CanGrow = false;
            this.textBox18.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.00200080871582D), Telerik.Reporting.Drawing.Unit.Cm(10.450153350830078D));
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.4747381210327148D), Telerik.Reporting.Drawing.Unit.Cm(0.3470839262008667D));
            this.textBox18.Style.Color = System.Drawing.Color.Black;
            this.textBox18.Style.Font.Bold = false;
            this.textBox18.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox18.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox18.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox18.Value = "** GRACIAS POR SU COMPRA **";
            // 
            // pageFooterSection1
            // 
            this.pageFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Inch(0.22580401599407196D);
            this.pageFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.htmlTextBox4,
            this.htmlTextBox5});
            this.pageFooterSection1.Name = "pageFooterSection1";
            // 
            // htmlTextBox4
            // 
            this.htmlTextBox4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.082903526723384857D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.htmlTextBox4.Name = "htmlTextBox4";
            this.htmlTextBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13.512083053588867D), Telerik.Reporting.Drawing.Unit.Cm(0.5206255316734314D));
            this.htmlTextBox4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.htmlTextBox4.Style.Visible = false;
            this.htmlTextBox4.Value = "<strong><span>ESTE DOCUMENTO ES UNA REPRESENTACION IMPRESA DE UN CFDI<br />EL REG" +
    "ISTRO DE ESTE DOCUMENTO PUEDE SER VERIFICADO EN LA PAGINA DE INTERNET DEL SAT</s" +
    "pan></strong>";
            // 
            // htmlTextBox5
            // 
            this.htmlTextBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.291028022766113D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.htmlTextBox5.Name = "htmlTextBox5";
            this.htmlTextBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.089897632598877D), Telerik.Reporting.Drawing.Unit.Cm(0.547083854675293D));
            this.htmlTextBox5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.htmlTextBox5.Value = "<p style=\"text-align: right\"><span style=\"font-size: 8pt\"><strong>P�gina {PageNum" +
    "ber} de {PageCount}</strong></span></p>";
            // 
            // RptRemision
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.pageFooterSection1});
            this.Name = "RptRemision";
            this.PageSettings.ContinuousPaper = false;
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Letter;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.UnitOfMeasure = Telerik.Reporting.Drawing.UnitType.Cm;
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(20.904998779296875D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

            }
		#endregion
		
		private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
		private Telerik.Reporting.DetailSection detail;
		private Telerik.Reporting.PageFooterSection pageFooterSection1;
        private Telerik.Reporting.Shape shpFolio;
        private Telerik.Reporting.TextBox txtEmisorNombre;
        private Telerik.Reporting.TextBox txtEmisorRFC;
        private Telerik.Reporting.TextBox txtEmisorExpedido;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.TextBox txtReceptorNombre;
        private Telerik.Reporting.TextBox txtReceptorCiudad;
        private Telerik.Reporting.TextBox txtReceptorColonia;
        private Telerik.Reporting.TextBox txtReceptorDireccion;
        private Telerik.Reporting.TextBox txtReceptorRFC;
        private Telerik.Reporting.TextBox txtFecha;
        private Telerik.Reporting.TextBox txtCondicionPago;
        private Telerik.Reporting.TextBox txtMetodoDePago;
        private Telerik.Reporting.TextBox txtPedido;
        private Telerik.Reporting.TextBox txtNumeroDeFolio;
        private Telerik.Reporting.TextBox txtTipoCFD;
        private Telerik.Reporting.TextBox txtEmplelado;
        private Telerik.Reporting.TextBox txtTels;
        private Telerik.Reporting.TextBox txtNumeroDeCliente;
        private Telerik.Reporting.PictureBox pbxLogo;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox txtCuentas;
        private Telerik.Reporting.TextBox textBox12;
        private Telerik.Reporting.TextBox textBox13;
        private Telerik.Reporting.TextBox textBox14;
        private Telerik.Reporting.TextBox textBox15;
        private Telerik.Reporting.TextBox textBox16;
        private Telerik.Reporting.TextBox textBox17;
        private Telerik.Reporting.Shape shape10;
        private Telerik.Reporting.PictureBox pictureBox1;
        private Telerik.Reporting.Panel panel1;
        private Telerik.Reporting.TextBox textBox31;
        private Telerik.Reporting.HtmlTextBox htmlPagare;
        private Telerik.Reporting.TextBox textBox24;
        private Telerik.Reporting.TextBox textBox28;
        private Telerik.Reporting.TextBox txtNoCertificado;
        private Telerik.Reporting.TextBox textBox30;
        private Telerik.Reporting.TextBox txtSelloDigital;
        private Telerik.Reporting.TextBox txtSelloSAT;
        private Telerik.Reporting.TextBox textBox37;
        private Telerik.Reporting.TextBox textBox38;
        private Telerik.Reporting.TextBox txtCadenaSAT;
        private Telerik.Reporting.TextBox textBox40;
        private Telerik.Reporting.HtmlTextBox htmlTimbreFecha;
        private Telerik.Reporting.TextBox textBox29;
        private Telerik.Reporting.TextBox textBox33;
        private Telerik.Reporting.TextBox textBox34;
        private Telerik.Reporting.TextBox textBox39;
        private Telerik.Reporting.TextBox textBox43;
        private Telerik.Reporting.HtmlTextBox htmlMoneda;
        private Telerik.Reporting.HtmlTextBox htmlTextBox3;
        private Telerik.Reporting.HtmlTextBox htmlTextBox6;
        private Telerik.Reporting.HtmlTextBox htmlEtiquetaIVA;
        private Telerik.Reporting.HtmlTextBox htmlSubTotalIVA;
        private Telerik.Reporting.HtmlTextBox htmlTotal;
        private Telerik.Reporting.Table table1;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox8;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.TextBox textBox10;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.ObjectDataSource objectDataSource1;
        private Telerik.Reporting.Shape shape2;
        private Telerik.Reporting.Shape shape5;
        private Telerik.Reporting.Shape shape7;
        private Telerik.Reporting.Shape shape8;
        private Telerik.Reporting.Shape shape9;
        private Telerik.Reporting.TextBox textBox27;
        private Telerik.Reporting.TextBox txtNota;
        private Telerik.Reporting.TextBox txtTotal;
        private Telerik.Reporting.TextBox txtIVA;
        private Telerik.Reporting.TextBox txtSubtotal;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.Shape shape3;
        private Telerik.Reporting.TextBox txtRegimen;
        private Telerik.Reporting.TextBox textBox11;
        private Telerik.Reporting.HtmlTextBox htmlTextBox1;
        private Telerik.Reporting.HtmlTextBox htmlCantidadLetras;
        private Telerik.Reporting.TextBox txtCancelacion;
        private Telerik.Reporting.TextBox textBox18;
        private Telerik.Reporting.HtmlTextBox htmlTextBox4;
        private Telerik.Reporting.HtmlTextBox htmlTextBox5;
    }
}